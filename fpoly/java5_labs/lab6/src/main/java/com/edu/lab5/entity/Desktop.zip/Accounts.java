package com.edu.lab5.entity;

import java.util.List;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "accounts")
public class Accounts {
	@Id
	String username;
	String email, fullname, password, photo;
	boolean activated = true, admin = false;
	@OneToMany(mappedBy = "accounts")
	List<Orders> orders;

	public Accounts() {
	}

	public Accounts(String username, String email, String fullname, String password, String photo, boolean activated,
			boolean admin, List<Orders> orders) {
		this.username = username;
		this.email = email;
		this.fullname = fullname;
		this.password = password;
		this.photo = photo;
		this.activated = activated;
		this.admin = admin;
		this.orders = orders;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullname() {
		return this.fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoto() {
		return this.photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public boolean isActivated() {
		return this.activated;
	}

	public boolean getActivated() {
		return this.activated;
	}

	public void setActivated(boolean activated) {
		this.activated = activated;
	}

	public boolean isAdmin() {
		return this.admin;
	}

	public boolean getAdmin() {
		return this.admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public List<Orders> getOrders() {
		return this.orders;
	}

	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}

	public Accounts username(String username) {
		setUsername(username);
		return this;
	}

	public Accounts email(String email) {
		setEmail(email);
		return this;
	}

	public Accounts fullname(String fullname) {
		setFullname(fullname);
		return this;
	}

	public Accounts password(String password) {
		setPassword(password);
		return this;
	}

	public Accounts photo(String photo) {
		setPhoto(photo);
		return this;
	}

	public Accounts activated(boolean activated) {
		setActivated(activated);
		return this;
	}

	public Accounts admin(boolean admin) {
		setAdmin(admin);
		return this;
	}

	public Accounts orders(List<Orders> orders) {
		setOrders(orders);
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof Accounts)) {
			return false;
		}
		Accounts accounts = (Accounts) o;
		return Objects.equals(username, accounts.username) && Objects.equals(email, accounts.email)
				&& Objects.equals(fullname, accounts.fullname) && Objects.equals(password, accounts.password)
				&& Objects.equals(photo, accounts.photo) && activated == accounts.activated && admin == accounts.admin
				&& Objects.equals(orders, accounts.orders);
	}

	@Override
	public int hashCode() {
		return Objects.hash(username, email, fullname, password, photo, activated, admin, orders);
	}

	@Override
	public String toString() {
		return "{" +
				" username='" + getUsername() + "'" +
				", email='" + getEmail() + "'" +
				", fullname='" + getFullname() + "'" +
				", password='" + getPassword() + "'" +
				", photo='" + getPhoto() + "'" +
				", activated='" + isActivated() + "'" +
				", admin='" + isAdmin() + "'" +
				", orders='" + getOrders() + "'" +
				"}";
	}

}
