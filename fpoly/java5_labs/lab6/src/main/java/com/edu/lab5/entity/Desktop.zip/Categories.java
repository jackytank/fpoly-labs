package com.edu.lab5.entity;

import java.util.List;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "categories")
public class Categories {
	@Id
	String id;
	String name;
	@OneToMany(mappedBy = "categories")
	List<Products> products;

	public Categories() {
	}

	public Categories(String id, String name, List<Products> products) {
		this.id = id;
		this.name = name;
		this.products = products;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Products> getProducts() {
		return this.products;
	}

	public void setProducts(List<Products> products) {
		this.products = products;
	}

	public Categories id(String id) {
		setId(id);
		return this;
	}

	public Categories name(String name) {
		setName(name);
		return this;
	}

	public Categories products(List<Products> products) {
		setProducts(products);
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof Categories)) {
			return false;
		}
		Categories categories = (Categories) o;
		return Objects.equals(id, categories.id) && Objects.equals(name, categories.name)
				&& Objects.equals(products, categories.products);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, products);
	}

	@Override
	public String toString() {
		return "{" +
				" id='" + getId() + "'" +
				", name='" + getName() + "'" +
				", products='" + getProducts() + "'" +
				"}";
	}

}
