package com.edu.lab5.entity;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "orderdetails")
public class OrderDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	double price;
	int quantity;
	@ManyToOne
	@JoinColumn(name = "orderid")
	Orders orders;
	@ManyToOne
	@JoinColumn(name = "productid")
	Products products;

	public OrderDetails() {
	}

	public OrderDetails(int id, double price, int quantity, Orders orders, Products products) {
		this.id = id;
		this.price = price;
		this.quantity = quantity;
		this.orders = orders;
		this.products = products;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getPrice() {
		return this.price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return this.quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Orders getOrders() {
		return this.orders;
	}

	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	public Products getProducts() {
		return this.products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}

	public OrderDetails id(int id) {
		setId(id);
		return this;
	}

	public OrderDetails price(double price) {
		setPrice(price);
		return this;
	}

	public OrderDetails quantity(int quantity) {
		setQuantity(quantity);
		return this;
	}

	public OrderDetails orders(Orders orders) {
		setOrders(orders);
		return this;
	}

	public OrderDetails products(Products products) {
		setProducts(products);
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof OrderDetails)) {
			return false;
		}
		OrderDetails orderDetails = (OrderDetails) o;
		return id == orderDetails.id && price == orderDetails.price && quantity == orderDetails.quantity
				&& Objects.equals(orders, orderDetails.orders) && Objects.equals(products, orderDetails.products);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, price, quantity, orders, products);
	}

	@Override
	public String toString() {
		return "{" +
				" id='" + getId() + "'" +
				", price='" + getPrice() + "'" +
				", quantity='" + getQuantity() + "'" +
				", orders='" + getOrders() + "'" +
				", products='" + getProducts() + "'" +
				"}";
	}

}
