package com.edu.lab5.entity;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "orders")
public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String address;
	@Temporal(TemporalType.DATE)
	@Column(name = "createdate")
	Date createDate = new Date();
	@ManyToOne
	@JoinColumn(name = "username")
	Accounts accounts;
	@OneToMany(mappedBy = "orders")
	List<OrderDetails> orderDetails;

	public Orders() {
	}

	public Orders(int id, String address, Date createDate, Accounts accounts, List<OrderDetails> orderDetails) {
		this.id = id;
		this.address = address;
		this.createDate = createDate;
		this.accounts = accounts;
		this.orderDetails = orderDetails;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Accounts getAccounts() {
		return this.accounts;
	}

	public void setAccounts(Accounts accounts) {
		this.accounts = accounts;
	}

	public List<OrderDetails> getOrderDetails() {
		return this.orderDetails;
	}

	public void setOrderDetails(List<OrderDetails> orderDetails) {
		this.orderDetails = orderDetails;
	}

	public Orders id(int id) {
		setId(id);
		return this;
	}

	public Orders address(String address) {
		setAddress(address);
		return this;
	}

	public Orders createDate(Date createDate) {
		setCreateDate(createDate);
		return this;
	}

	public Orders accounts(Accounts accounts) {
		setAccounts(accounts);
		return this;
	}

	public Orders orderDetails(List<OrderDetails> orderDetails) {
		setOrderDetails(orderDetails);
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof Orders)) {
			return false;
		}
		Orders orders = (Orders) o;
		return id == orders.id && Objects.equals(address, orders.address)
				&& Objects.equals(createDate, orders.createDate) && Objects.equals(accounts, orders.accounts)
				&& Objects.equals(orderDetails, orders.orderDetails);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, address, createDate, accounts, orderDetails);
	}

	@Override
	public String toString() {
		return "{" +
				" id='" + getId() + "'" +
				", address='" + getAddress() + "'" +
				", createDate='" + getCreateDate() + "'" +
				", accounts='" + getAccounts() + "'" +
				", orderDetails='" + getOrderDetails() + "'" +
				"}";
	}

}
