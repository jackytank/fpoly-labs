package com.edu.lab5.entity;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "products")
public class Products {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String name, image;
	double price;
	boolean available = true;
	@Temporal(TemporalType.DATE)
	@Column(name = "createdate")
	Date createDate = new Date();
	@ManyToOne
	@JoinColumn(name = "categoryid")
	Categories categories;
	@OneToMany(mappedBy = "products")
	List<OrderDetails> orderDetails;

	public Products() {
	}

	public Products(int id, String name, String image, double price, boolean available, Date createDate,
			Categories categories, List<OrderDetails> orderDetails) {
		this.id = id;
		this.name = name;
		this.image = image;
		this.price = price;
		this.available = available;
		this.createDate = createDate;
		this.categories = categories;
		this.orderDetails = orderDetails;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public double getPrice() {
		return this.price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public boolean isAvailable() {
		return this.available;
	}

	public boolean getAvailable() {
		return this.available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Categories getCategories() {
		return this.categories;
	}

	public void setCategories(Categories categories) {
		this.categories = categories;
	}

	public List<OrderDetails> getOrderDetails() {
		return this.orderDetails;
	}

	public void setOrderDetails(List<OrderDetails> orderDetails) {
		this.orderDetails = orderDetails;
	}

	public Products id(int id) {
		setId(id);
		return this;
	}

	public Products name(String name) {
		setName(name);
		return this;
	}

	public Products image(String image) {
		setImage(image);
		return this;
	}

	public Products price(double price) {
		setPrice(price);
		return this;
	}

	public Products available(boolean available) {
		setAvailable(available);
		return this;
	}

	public Products createDate(Date createDate) {
		setCreateDate(createDate);
		return this;
	}

	public Products categories(Categories categories) {
		setCategories(categories);
		return this;
	}

	public Products orderDetails(List<OrderDetails> orderDetails) {
		setOrderDetails(orderDetails);
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof Products)) {
			return false;
		}
		Products products = (Products) o;
		return id == products.id && Objects.equals(name, products.name) && Objects.equals(image, products.image)
				&& price == products.price && available == products.available
				&& Objects.equals(createDate, products.createDate) && Objects.equals(categories, products.categories)
				&& Objects.equals(orderDetails, products.orderDetails);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, image, price, available, createDate, categories, orderDetails);
	}

	@Override
	public String toString() {
		return "{" +
				" id='" + getId() + "'" +
				", name='" + getName() + "'" +
				", image='" + getImage() + "'" +
				", price='" + getPrice() + "'" +
				", available='" + isAvailable() + "'" +
				", createDate='" + getCreateDate() + "'" +
				", categories='" + getCategories() + "'" +
				", orderDetails='" + getOrderDetails() + "'" +
				"}";
	}

}
